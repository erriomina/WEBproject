from django.contrib import admin
from .models import Analytics

# Register your models here.
admin.site.register(Analytics)